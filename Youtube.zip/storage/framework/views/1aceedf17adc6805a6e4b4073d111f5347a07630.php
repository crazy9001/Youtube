<div class="box box-color box-bordered">

    <div class="box-title">
        <h3>
            <i class="fa fa-th-list"></i>Hành động
        </h3>
    </div>

    <div class="box-content">
        <p>
            <button type="submit" name="submit" class="btn btn-inverse" value="cancer">
                <i class="fa fa-backward"></i> Hủy bỏ
            </button>
            <button  type="submit" name="submit" class="btn btn-success" value="save">
                <i class="fa fa-save"></i> Lưu và tiếp tục
            </button>
        </p>
    </div>

</div>