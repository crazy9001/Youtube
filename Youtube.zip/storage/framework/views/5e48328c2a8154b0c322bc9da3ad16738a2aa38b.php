<script type="text/javascript">

    var Youtube = Youtube || {};

    Youtube.languages = {
        'notices_msg': {
            'success': '<?php echo e(trans('bases::layouts.success')); ?>!',
            'error': '<?php echo e(trans('bases::layouts.error')); ?>!'
        },
    }
</script>

<?php if(session()->has('success_msg') || session()->has('error_msg') || isset($errors) || isset($error_msg)): ?>
    <script type="text/javascript">
        $(document).ready(function () {

            <?php if(session()->has('success_msg')): ?>
            Youtube.showNotice('success', '<?php echo e(session('success_msg')); ?>', Youtube.languages.notices_msg.success);
            <?php endif; ?>
            <?php if(session()->has('error_msg')): ?>
            Youtube.showNotice('error', '<?php echo e(session('error_msg')); ?>', Youtube.languages.notices_msg.error);
            <?php endif; ?>
            <?php if(isset($error_msg)): ?>
            Youtube.showNotice('error', '<?php echo e($error_msg); ?>', Youtube.languages.notices_msg.error);
            <?php endif; ?>
            <?php if(isset($errors)): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            Youtube.showNotice('error', '<?php echo e($error); ?>', Youtube.languages.notices_msg.error);
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    </script>
<?php endif; ?>