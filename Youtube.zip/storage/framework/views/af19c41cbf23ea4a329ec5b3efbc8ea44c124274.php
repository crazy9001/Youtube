<?php $__env->startSection('page'); ?>


    <?php
        $userName = '';
        $createdDate = '';
        if (Sentinel::check()) {
            $user = Sentinel::getUser();
            $userName = (isset($user->first_name) && !empty($user->first_name) ? $user->first_name : '') . ' ' . (isset($user->last_name) && !empty($user->last_name) ? $user->last_name : '');
        }
    ?>

    <?php echo $__env->make('bases::partials.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    

    <div id="main" style="margin-left: 0">

        <div class="container-fluid">

            <?php echo $__env->yieldContent('content'); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('bases::layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>