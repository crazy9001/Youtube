<ul class='main-nav'>
    
    <?php echo App::make('App\Helpers\MenuItemHelper')->getMenu(); ?>

    
</ul>