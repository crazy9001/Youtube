<?php $__env->startSection('body-class'); ?>
    login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>

    <div class="wrapper">
        <h1>
            <a href="<?php echo e(route('dashboard.index')); ?>">
                <img src="<?php echo e(asset('images/logo-big.png')); ?>" alt="" class='retina-ready' width="59" height="49">FLAT</a>
        </h1>
        <div class="login-body">
            <h2><?php echo e(trans('auth::auth.login.title')); ?></h2>
            <?php echo $__env->yieldContent('content'); ?>
            <div class="forget">
                <a href="#">
                    <span><?php echo e(trans('auth::auth.forgot_password.title')); ?></span>
                </a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('bases::layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>