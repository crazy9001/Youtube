<?php $__env->startSection('content'); ?>
    <div class="page-header"></div>

    <div class="breadcrumbs">
        <ul>
            <li>
                <a href="<?php echo e(route('dashboard.index')); ?>">Bảng điều khiển</a>
                <i class="fa fa-angle-right"></i>
            </li>
            <li>
                <a href="<?php echo e(route('group.index')); ?>">Nhóm</a>
                <i class="fa fa-angle-right"></i>
            </li>
            <li>
                <a href="<?php echo e(route('group.create')); ?>">Thêm nhóm mới</a>
            </li>
        </ul>
    </div>
    <?php echo Form::open(['class' => 'form-horizontal form-bordered']); ?>

    <div class="row">

        <div class="col-sm-9">

            <div class="box box-color box-bordered">

                <div class="box-title">
                    <h3>
                        <i class="fa fa-th-list"></i>Thông tin cơ bản
                    </h3>
                </div>

                <div class="box-content nopadding">


                        <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                            <label for="textfield" class="control-label col-sm-2 required">Tên nhóm</label>
                            <div class="col-sm-10">
                                <input type="text" name="name" id="name" class="form-control" placeholder="Nhập tên nhóm">
                                <?php if($errors->has('name')): ?>
                                    <span id="username-error" class="help-block has-error"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php if($errors->has('parent_id')): ?> has-error <?php endif; ?>">
                            <label for="select" class="control-label col-sm-2 required">Nhóm cha</label>
                            <div class="col-sm-10">
                                <?php echo Form::select('parent_id', $groups, old('parent_id'), ['class' => 'form-control', 'id' => 'parent_id']); ?>

                                <?php if($errors->has('parent_id')): ?>
                                    <span id="username-error" class="help-block has-error"><?php echo e($errors->first('parent_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php if($errors->has('tags')): ?> has-error <?php endif; ?>">
                            <label for="textfield" class="control-label col-sm-2 required">Tags</label>
                            <div class="col-sm-10">
                                <input type="text" name="tags" id="tags" class="tagsinput form-control" value="">
                                <span class="label label-info">Mỗi tag cách nhau bởi phím "enter"</span>
                                <?php if($errors->has('tags')): ?>
                                    <span id="username-error" class="help-block has-error"><?php echo e($errors->first('tags')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php if($errors->has('icon')): ?> has-error <?php endif; ?>">
                            <label for="textfield" class="control-label col-sm-2">Biểu tượng</label>
                            <div class="col-sm-10">
                                <input type="text" name="icon" id="icon" class="form-control" placeholder="Ví dụ: fa fa-home">
                                <?php if($errors->has('icon')): ?>
                                    <span id="username-error" class="help-block has-error"><?php echo e($errors->first('icon')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                </div>

            </div>

        </div>


        <div class="col-sm-3">

            <?php echo $__env->make('bases::elements.form-actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>


    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('bases::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>