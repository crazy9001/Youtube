<?php $__env->startSection('content'); ?>

    <?php echo Form::open(['route' => 'access.login', 'class' => 'form-validate', 'id' => 'test']); ?>

        <div class="form-group <?php if($errors->has('username')): ?> has-error <?php endif; ?>">
            <div class="email controls">
                <?php echo Form::text('email', old('username', ''), ['class' => 'form-control', 'placeholder' => trans('auth::auth.login.username'), /*'data-rule-required' => 'true', 'data-rule-email' => 'true'*/]); ?>

                <?php if($errors->has('username')): ?>
                    <span id="username-error" class="help-block has-error"><?php echo e($errors->first('username')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group <?php if($errors->has('username')): ?> has-error <?php endif; ?>">
            <div class="pw controls">
                <?php echo Form::input('password', 'password', '', ['class' => 'form-control', 'placeholder' => trans('auth::auth.login.password'), /*'data-rule-required' => 'true'*/]); ?>

                <?php if($errors->has('username')): ?>
                    <span id="password-error" class="help-block has-error"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="submit">
            <div class="remember">
                <input type="checkbox" name="remember" class='icheck-me' data-skin="square" data-color="blue" id="remember">
                <label for="remember"><?php echo e(trans('auth::auth.login.remember')); ?></label>
            </div>
            <input type="submit" value="<?php echo e(trans('auth::auth.login.login')); ?>" class='btn btn-primary'>
        </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth::auth.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>