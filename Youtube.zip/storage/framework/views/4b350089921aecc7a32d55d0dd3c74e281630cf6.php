<?php $__env->startSection('content'); ?>

    <?php if(Permission::isSuperAdmin()): ?>
        <!--Super Admins-->
        <?php echo $__env->make('dashboard::partials.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Permission::isUser()): ?>
        <?php echo $__env->make('dashboard::partials.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bases::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>