<?php return array (
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'key' => 'base64:mkbtvXCQM9Z+8n8ZpXOaH6DRABp1ypoUXQ3cUYdbUEQ=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\HelperServiceProvider',
      23 => 'Alaouy\\Youtube\\YoutubeServiceProvider',
      24 => 'App\\Providers\\AppServiceProvider',
      25 => 'App\\Providers\\AuthServiceProvider',
      26 => 'App\\Providers\\EventServiceProvider',
      27 => 'App\\Providers\\RouteServiceProvider',
      28 => 'Cartalyst\\Sentinel\\Laravel\\SentinelServiceProvider',
      29 => 'Collective\\Html\\HtmlServiceProvider',
      30 => 'Prettus\\Repository\\Providers\\RepositoryServiceProvider',
      31 => 'Nestable\\NestableServiceProvider',
      32 => 'Youtube\\Base\\Providers\\BaseServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Activation' => 'Cartalyst\\Sentinel\\Laravel\\Facades\\Activation',
      'Reminder' => 'Cartalyst\\Sentinel\\Laravel\\Facades\\Reminder',
      'Permission' => 'App\\Helpers\\PermissionHelper',
      'Helper' => 'App\\Helpers\\BasicHelper',
      'Sentinel' => 'Cartalyst\\Sentinel\\Laravel\\Facades\\Sentinel',
      'Form' => 'Collective\\Html\\FormFacade',
      'HTML' => 'Collective\\Html\\HtmlFacade',
      'Youtube' => 'Alaouy\\Youtube\\Facades\\Youtube',
      'Nestable' => 'Nestable\\Facades\\NestableService',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'encrypted' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'D:\\Source\\Youtube\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'laravel_cache',
  ),
  'cartalyst' => 
  array (
    'sentinel' => 
    array (
      'session' => 'cartalyst_sentinel',
      'cookie' => 'cartalyst_sentinel',
      'users' => 
      array (
        'model' => 'Cartalyst\\Sentinel\\Users\\EloquentUser',
      ),
      'roles' => 
      array (
        'model' => 'Cartalyst\\Sentinel\\Roles\\EloquentRole',
      ),
      'permissions' => 
      array (
        'class' => 'Cartalyst\\Sentinel\\Permissions\\StandardPermissions',
      ),
      'persistences' => 
      array (
        'model' => 'Cartalyst\\Sentinel\\Persistences\\EloquentPersistence',
        'single' => false,
      ),
      'checkpoints' => 
      array (
        0 => 'throttle',
        1 => 'activation',
      ),
      'activations' => 
      array (
        'model' => 'Cartalyst\\Sentinel\\Activations\\EloquentActivation',
        'expires' => 259200,
        'lottery' => 
        array (
          0 => 2,
          1 => 100,
        ),
      ),
      'reminders' => 
      array (
        'model' => 'Cartalyst\\Sentinel\\Reminders\\EloquentReminder',
        'expires' => 14400,
        'lottery' => 
        array (
          0 => 2,
          1 => 100,
        ),
      ),
      'throttling' => 
      array (
        'model' => 'Cartalyst\\Sentinel\\Throttling\\EloquentThrottle',
        'global' => 
        array (
          'interval' => 900,
          'thresholds' => 
          array (
            10 => 1,
            20 => 2,
            30 => 4,
            40 => 8,
            50 => 16,
            60 => 12,
          ),
        ),
        'ip' => 
        array (
          'interval' => 900,
          'thresholds' => 5,
        ),
        'user' => 
        array (
          'interval' => 900,
          'thresholds' => 5,
        ),
      ),
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'youtube',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'youtube',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => false,
        'engine' => NULL,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'youtube',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'youtube',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\Source\\Youtube\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\Source\\Youtube\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
      ),
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'D:\\Source\\Youtube\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'D:\\Source\\Youtube\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 7,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.mailtrap.io',
    'port' => '2525',
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'encryption' => NULL,
    'username' => NULL,
    'password' => NULL,
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'D:\\Source\\Youtube\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'menuitems' => 
  array (
    'super-admin' => 
    array (
      'Bảng điều khiển' => 'dashboard.index',
      'Quản lí nhóm' => 
      array (
        'Xem tất cả' => 'group.index',
        'Thêm mới' => 'group.create',
      ),
      'Quản lí kênh' => 'channel.index',
      'Quản lí video' => 'video.index',
      'Quản lí API key' => 'key.index',
    ),
    'Icons' => 
    array (
    ),
  ),
  'nestable' => 
  array (
    'parent' => 'parent_id',
    'primary_key' => 'id',
    'generate_url' => true,
    'childNode' => 'child',
    'body' => 
    array (
      0 => 'id',
      1 => 'name',
      2 => 'slug',
    ),
    'html' => 
    array (
      'label' => 'name',
      'href' => 'slug',
    ),
    'dropdown' => 
    array (
      'prefix' => '',
      'label' => 'name',
      'value' => 'id',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'repository' => 
  array (
    'pagination' => 
    array (
      'limit' => 15,
    ),
    'fractal' => 
    array (
      'params' => 
      array (
        'include' => 'include',
      ),
      'serializer' => 'League\\Fractal\\Serializer\\DataArraySerializer',
    ),
    'cache' => 
    array (
      'enabled' => false,
      'minutes' => 30,
      'repository' => 'cache',
      'clean' => 
      array (
        'enabled' => true,
        'on' => 
        array (
          'create' => true,
          'update' => true,
          'delete' => true,
        ),
      ),
      'params' => 
      array (
        'skipCache' => 'skipCache',
      ),
      'allowed' => 
      array (
        'only' => NULL,
        'except' => NULL,
      ),
    ),
    'criteria' => 
    array (
      'acceptedConditions' => 
      array (
        0 => '=',
        1 => 'like',
      ),
      'params' => 
      array (
        'search' => 'search',
        'searchFields' => 'searchFields',
        'filter' => 'filter',
        'orderBy' => 'orderBy',
        'sortedBy' => 'sortedBy',
        'with' => 'with',
        'searchJoin' => 'searchJoin',
      ),
    ),
    'generator' => 
    array (
      'basePath' => 'D:\\Source\\Youtube\\app',
      'rootNamespace' => 'App\\',
      'stubsOverridePath' => 'D:\\Source\\Youtube\\app',
      'paths' => 
      array (
        'models' => 'Entities',
        'repositories' => 'Repositories',
        'interfaces' => 'Repositories',
        'transformers' => 'Transformers',
        'presenters' => 'Presenters',
        'validators' => 'Validators',
        'controllers' => 'Http/Controllers',
        'provider' => 'RepositoryServiceProvider',
        'criteria' => 'Criteria',
      ),
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'D:\\Source\\Youtube\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'D:\\Source\\Youtube\\resources\\views',
    ),
    'compiled' => 'D:\\Source\\Youtube\\storage\\framework\\views',
  ),
  'youtube' => 
  array (
    'admin_dir' => 'admin',
    'key' => 'AIzaSyA7fhC52vCBkD-PiKf_tIDU40lcxk1j_YA',
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'assets' => 
  array (
    'javascript' => 
    array (
      0 => 'jquery',
      1 => 'nicescroll',
      2 => 'jquery-ui',
      3 => 'slimscroll',
      4 => 'bootstrap',
      5 => 'form',
      6 => 'eakroko',
      7 => 'application',
      8 => 'demonstration',
      9 => 'toastr',
      10 => 'core',
    ),
    'stylesheets' => 
    array (
      0 => 'bootstrap',
      1 => 'jquery-ui',
      2 => 'core',
      3 => 'themes',
      4 => 'toastr',
    ),
    'resources' => 
    array (
      'javascript' => 
      array (
        'jquery' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/jquery.min.js',
          ),
        ),
        'nicescroll' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/nicescroll/jquery.nicescroll.min.js',
          ),
        ),
        'jquery-ui' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/jquery-ui/jquery-ui.js',
          ),
        ),
        'slimscroll' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/slimscroll/jquery.slimscroll.min.js',
          ),
        ),
        'validation' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => 
            array (
              0 => 'js/plugins/validation/jquery.validate.min.js',
              1 => 'js/plugins/validation/additional-methods.min.js',
            ),
          ),
        ),
        'icheck' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => 'js/plugins/icheck/jquery.icheck.min.js',
          ),
        ),
        'bootstrap' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/bootstrap.min.js',
          ),
        ),
        'form' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/form/jquery.form.min.js',
          ),
        ),
        'toastr' => 
        array (
          'use_cdn' => true,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/toastr/toastr.min.js',
            'cdn' => '//cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.2/toastr.min.js',
          ),
        ),
        'eakroko' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/eakroko.js',
          ),
        ),
        'application' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/application.min.js',
          ),
        ),
        'demonstration' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/demonstration.min.js',
          ),
        ),
        'core' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/core.js',
          ),
        ),
        'complexify' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/complexify/jquery.complexify.min.js',
          ),
        ),
        'tagsinput' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/tagsinput/jquery.tagsinput.min.js',
          ),
        ),
        'chosen' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/chosen/chosen.jquery.min.js',
          ),
        ),
        'multiselect' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/multiselect/jquery.multi-select.js',
          ),
        ),
        'select2' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/select2/select2.min.js',
          ),
        ),
        'mockjax' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/mockjax/jquery.mockjax.js',
          ),
        ),
        'treeview' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/treeview/jquery-treeview.js',
          ),
        ),
        'nestable' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/jquery.nestable.js',
          ),
        ),
        'editable' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/editable/bootstrap-editable.min.js',
          ),
        ),
        'data-table' => 
        array (
          'use_cdn' => false,
          'location' => 'bottom',
          'src' => 
          array (
            'local' => '/js/plugins/datatables/jquery.dataTables.min.js',
          ),
        ),
      ),
      'stylesheets' => 
      array (
        'bootstrap' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/bootstrap.min.css',
          ),
        ),
        'icheck' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/icheck/all.css',
          ),
        ),
        'jquery-ui' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/jquery-ui/jquery-ui.min.css',
          ),
        ),
        'toastr' => 
        array (
          'use_cdn' => true,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/toastr/toastr.min.css',
            'cdn' => '//cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.2/toastr.min.css',
          ),
        ),
        'core' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/style.css',
          ),
        ),
        'themes' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/themes.css',
          ),
        ),
        'tagsinput' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/tagsinput/jquery.tagsinput.css',
          ),
        ),
        'chosen' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/chosen/chosen.css',
          ),
        ),
        'multiselect' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/multiselect/multi-select.css',
          ),
        ),
        'select2' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/select2/select2.css',
          ),
        ),
        'treeview' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/treeview/jquery.treeview.css',
          ),
        ),
        'editable' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/editable/bootstrap-editable.css',
          ),
        ),
        'data-table' => 
        array (
          'use_cdn' => false,
          'location' => 'top',
          'src' => 
          array (
            'local' => '/css/plugins/datatable/TableTools.css',
          ),
        ),
      ),
    ),
  ),
  'dashboard' => 
  array (
  ),
  'users' => 
  array (
  ),
  'groups' => 
  array (
  ),
  'videos' => 
  array (
  ),
  'channel' => 
  array (
  ),
  'tinker' => 
  array (
    'dont_alias' => 
    array (
    ),
  ),
);
