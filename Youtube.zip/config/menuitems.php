<?php
/**
 * Created by PhpStorm.
 * User: Demon Warlock
 * Date: 5/16/2018
 * Time: 9:29 PM
 */

return array(

    'super-admin' => [
        'Bảng điều khiển' => 'dashboard.index',
        'Quản lí nhóm' => [
            'Xem tất cả' => 'group.index',
            'Thêm mới' => 'group.create'
        ],
        'Quản lí kênh' =>  'channel.index',
        'Quản lí video' => 'video.index',
        'Quản lí API key' => 'key.index'

    ],
    /**
     * Icons for all
     *
     */
    'Icons' => [
        /*'Bảng điều khiển' => '<i class="fa fa-dashboard"></i>',*/
    ]

);