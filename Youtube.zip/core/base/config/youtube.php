<?php
/**
 * Created by PhpStorm.
 * User: Demon Warlock
 * Date: 5/11/2018
 * Time: 6:41 PM
 */
return array(
    'admin_dir' => env('ADMIN_DIR', 'admin'),
);