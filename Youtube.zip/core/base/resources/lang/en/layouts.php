<?php

return [
    'error' => 'Error',
    'success' => 'Success',
];
