<?php
return array(

    'login' =>  [
        'username'  =>  [
            'required'  =>  'Please enter your account'
        ],
        'password'  =>  [
            'required'  =>  'Please enter your password'
        ]
    ]

);